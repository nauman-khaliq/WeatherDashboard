package com.naumankhaliq.weatherdashboard.domain

data class WeatherData(
    val cityName: String,
    val temperature: Double,
    val condition: String,
    val iconCode: String? = null
)