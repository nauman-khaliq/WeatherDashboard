/*
 * MIT License
 *
 * Copyright (c) 2025 Nauman Khaliq
 */

package com.naumankhaliq.weatherdashboard.presentation.main

import android.os.Bundle
import android.view.View
import android.view.ViewTreeObserver
import androidx.activity.viewModels
import androidx.navigation.NavDirections
import androidx.navigation.fragment.FragmentNavigator
import androidx.navigation.fragment.NavHostFragment
import com.naumankhaliq.weatherdashboard.R
import com.naumankhaliq.weatherdashboard.databinding.ActivityMainBinding
import com.naumankhaliq.weatherdashboard.presentation.base.BaseActivity
import com.naumankhaliq.weatherdashboard.utils.PreferenceHelper
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import java.util.Timer
import javax.inject.Inject
import kotlin.concurrent.schedule


@ExperimentalCoroutinesApi
@AndroidEntryPoint
class MainActivity : BaseActivity<MainViewModel, ActivityMainBinding>() {

    override val mViewModel: MainViewModel by viewModels()
    var ready = false

    @Inject
    lateinit var preferenceHelper: PreferenceHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.AppTheme_NoActionBar) // Set AppTheme before setting content view.
        super.onCreate(savedInstanceState)
        setContentView(mViewBinding.root)

        Timer().schedule(1000) {
            ready = true
        }
        // Set up an OnPreDrawListener to the root view.
        val content: View = findViewById(android.R.id.content)
        content.viewTreeObserver.addOnPreDrawListener(
            object : ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    // Check if the initial data is ready.
                    return if (ready) {
                        // The content is ready; start drawing.
                        content.viewTreeObserver.removeOnPreDrawListener(this)
                        true
                    } else {
                        // The content is not ready; suspend.
                        false
                    }
                }
            }
        )

//      It's very important to set the toolbar to prevent errors of the NPE type,
//      this is because the application style is .NoActionBar
//      setSupportActionBar(mViewBinding.toolbarLayout.toolbar)
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController
        initView()

    }

    override fun onStart() {
        super.onStart()
        //handleNetworkChanges()
    }

    override fun navigateTo(direction: NavDirections, navExtras: FragmentNavigator.Extras?) {
        super.navigateTo(direction, navExtras)
    }
    /**
     * Initializing views and register click listeners
     */
    private fun initView() {
        mViewBinding.run {

        }
    }

    override fun getViewBinding(): ActivityMainBinding = ActivityMainBinding.inflate(layoutInflater)

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp()
    }

    companion object {
        const val ANIMATION_DURATION = 1000L
        const val TAG = "ad_i"
        const val test = "Final\nMar 18 - 7:00 PM\nLahore"
    }
}
