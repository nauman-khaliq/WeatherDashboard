/*
 * MIT License
 *
 * Copyright (c) 2025 Nauman Khaliq
 *
 */

package com.naumankhaliq.weatherdashboard.data.repository

import com.naumankhaliq.weatherdashboard.data.remote.api.WeatherDashboardService
import com.naumankhaliq.weatherdashboard.data.remote.model.weather.WeatherResponse
import com.naumankhaliq.weatherdashboard.data.remote.model.weather.toDomain
import com.naumankhaliq.weatherdashboard.data.util.Resource
import com.naumankhaliq.weatherdashboard.domain.WeatherDashboardRepository
import com.naumankhaliq.weatherdashboard.domain.WeatherData
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import retrofit2.Response
import javax.inject.Inject

/**
 * Singleton repository for fetching data from remote and storing it in database
 * for offline capability. This is Single source of data.
 */
@ExperimentalCoroutinesApi
open class WeatherDashboardRepositoryImp @Inject constructor(
    val weatherDashboardService: WeatherDashboardService
) : WeatherDashboardRepository {
    override fun getWeatherData(cityName: String): Flow<Resource<WeatherData?>> {
        return object : NetworkBoundRepository<WeatherResponse, WeatherData?>() {
            override suspend fun fetchFromRemote(): Response<WeatherResponse> {
                return weatherDashboardService.getOpenMapWeatherDataForCity(cityName)
            }
            override fun processResponse(response: WeatherResponse): WeatherData? {
                return  response.toDomain()
            }

        }.asFlow()
    }


}
