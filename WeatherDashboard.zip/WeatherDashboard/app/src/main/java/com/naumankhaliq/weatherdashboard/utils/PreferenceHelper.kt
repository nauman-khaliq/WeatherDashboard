/*
 * MIT License
 *
 * Copyright (c) 2025 Nauman Khaliq
 *
 */
package com.naumankhaliq.weatherdashboard.utils

import android.content.SharedPreferences
import javax.inject.Inject
/**
 * A helper class that will be used to manage data for [SharedPreferences]
 * Only class that will be used to communicate with [SharedPreferences]
 */
class PreferenceHelper @Inject constructor(private val preferences: SharedPreferences) {
    fun saveLastSearchedCity(cityName: String) {
        preferences.edit().putString(LAST_SEARCHED_CITY, cityName).apply()
    }
    fun getLastSearchedCity(): String {
        return preferences.getString(LAST_SEARCHED_CITY, "") ?: ""
    }
    fun deleteLastSearchedCity() {
        preferences.edit().remove(LAST_SEARCHED_CITY).apply()
    }
    companion object {
        const val LAST_SEARCHED_CITY = "last_searched_city"
    }
}