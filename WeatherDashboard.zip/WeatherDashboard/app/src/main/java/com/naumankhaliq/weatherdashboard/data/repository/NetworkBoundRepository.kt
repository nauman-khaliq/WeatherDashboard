/*
 * MIT License
 *
 * Copyright (c) 2022 Nauman Khaliq
 */

package com.naumankhaliq.weatherdashboard.data.repository

import androidx.annotation.WorkerThread
import com.naumankhaliq.weatherdashboard.data.remote.model.ErrorResponse
import com.naumankhaliq.weatherdashboard.data.remote.model.ErrorResponse.Companion.parseErrorResponse
import com.naumankhaliq.weatherdashboard.data.util.DataFrom
import com.naumankhaliq.weatherdashboard.data.util.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import retrofit2.HttpException
import retrofit2.Response
import java.io.IOException
import java.net.UnknownHostException

/**
 * A repository which provides resource from local database as well as remote end point.
 *
 * [RESULT] represents the type for network.
 */
@ExperimentalCoroutinesApi
abstract class NetworkBoundRepository<RESPONSE, DOMAIN> {

    fun asFlow() = flow<Resource<DOMAIN>> {

        // Fetch latest posts from remote
        val apiResponse = fetchFromRemote()

        // Parse body
        val responseBody = apiResponse.body()

        // Check for response validation
        if (apiResponse.isSuccessful) {
            responseBody?.let {
                val domainModel = processResponse(responseBody)
                emit(Resource.Success(domainModel, DataFrom.REMOTE))
            }
        } else {
            // Something went wrong! Emit Error state.
            val errObj: ErrorResponse? = apiResponse.parseErrorResponse()
            emit(Resource.Failed(errObj?.message ?: "Something went wrong"))

        }
    }.catch { ex ->
        ex.printStackTrace()
        val errorMessage = when (ex) {
            is IOException -> "Please check your internet connection."
            is HttpException -> "${ex.code()} ${ex.message()}"
            else -> ex.message ?: "Something went wrong"
        }
        emit(Resource.Failed(errorMessage))
    }.flowOn(Dispatchers.IO)

    /**
     * Fetches [Response] from the remote end point.
     */
    @WorkerThread
    protected abstract suspend fun fetchFromRemote(): Response<RESPONSE>

    protected abstract fun processResponse(response: RESPONSE): DOMAIN

}
