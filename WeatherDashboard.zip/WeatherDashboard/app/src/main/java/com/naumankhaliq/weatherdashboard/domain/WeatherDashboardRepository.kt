package com.naumankhaliq.weatherdashboard.domain

import com.naumankhaliq.weatherdashboard.data.util.Resource
import kotlinx.coroutines.flow.Flow

interface WeatherDashboardRepository {
    /**
     * Fetches weather data from api
     * @return Flow<Resource<List<Movie>>>
     */
    fun getWeatherData(cityName: String): Flow<Resource<WeatherData?>>
}