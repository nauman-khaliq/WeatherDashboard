/*
 * MIT License
 *
 * Copyright (c) 2025 Nauman Khaliq
 */
package com.naumankhaliq.weatherdashboard.data.remote.model.weather

import android.annotation.SuppressLint
import android.os.Parcelable
import com.naumankhaliq.weatherdashboard.domain.WeatherData
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import kotlinx.parcelize.Parcelize

@SuppressLint("ParcelCreator")
@Parcelize
@JsonClass(generateAdapter = true)
data class WeatherResponse(
    @Json(name = "weather") val weather: List<Weather>?,
    @Json(name = "main") val main: Main?,
    @Json(name = "id") val id: Long?,
    @Json(name = "name") val name: String?,
) : Parcelable

fun WeatherResponse.toDomain(): WeatherData? {
    val main = this.main ?: return null
    val weather = this.weather?.firstOrNull() ?: return null

    return WeatherData(
        cityName = this.name.orEmpty(),
        temperature = main.temp ?: 0.0,
        condition = weather.main.orEmpty(), // Clouds or rain
        iconCode = weather.icon // weather icon response
    )
}






