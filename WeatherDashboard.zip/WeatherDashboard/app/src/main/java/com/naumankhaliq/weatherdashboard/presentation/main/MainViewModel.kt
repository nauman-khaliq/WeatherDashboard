/*
 * MIT License
 *
 * Copyright (c) 2025 Nauman Khaliq
 */

package com.naumankhaliq.weatherdashboard.presentation.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.naumankhaliq.weatherdashboard.domain.WeatherDashboardRepository
import com.naumankhaliq.weatherdashboard.domain.WeatherData
import com.naumankhaliq.weatherdashboard.presentation.model.State
import com.naumankhaliq.weatherdashboard.utils.PreferenceHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for [MainActivity]
 */
@ExperimentalCoroutinesApi
@HiltViewModel
class MainViewModel @Inject constructor(
    private val weatherDashboardRepository: WeatherDashboardRepository,
    private val preferenceHelper: PreferenceHelper
) :
    ViewModel() {

    private val _weatherData: MutableStateFlow<State<WeatherData?>> = MutableStateFlow(State.idle())
    val weatherData: StateFlow<State<WeatherData?>> = _weatherData

    /**
     * Gets weather data using [weatherDashboardRepository] mapping on [State] and and passing data to _weatherData [StateFlow]
     */
    fun getWeatherDataForCity(city: String) {
        _weatherData.value = State.loading()
        viewModelScope.launch {
            weatherDashboardRepository.getWeatherData(city)
                .map {
                    State.fromResource(it)
                }
                .collectLatest {
                    _weatherData.value = it
                }
        }
    }

    /**
     * Saves city name to shared preferences
     * @param cityName [String]
     */
    fun saveLastSearchedCity(cityName: String) {
        preferenceHelper.saveLastSearchedCity(cityName)
    }

    /**
     * Saves city name to shared preferences
     */
    fun getLastSearchedCity(): String {
        return preferenceHelper.getLastSearchedCity()
    }
}


