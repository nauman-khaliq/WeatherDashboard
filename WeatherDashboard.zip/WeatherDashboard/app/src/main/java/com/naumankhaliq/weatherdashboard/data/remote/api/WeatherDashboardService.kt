/*
 * MIT License
 *
 * Copyright (c) 2025 Nauman Khaliq
 */

package com.naumankhaliq.weatherdashboard.data.remote.api

import com.naumankhaliq.weatherdashboard.data.remote.model.weather.WeatherResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Service to fetch Open Map Weather data from server [BuildConfig.BASE_URL].
 */
interface WeatherDashboardService {

    @GET("/data/2.5/weather")
    suspend fun getOpenMapWeatherDataForCity(
        @Query("q") cityName: String,
        @Query("units") units: String = "metric",
        @Query("appid") apiKey: String = "d49a7e1e0723d8a437da7d815b32bca0"
    ): Response<WeatherResponse>
}
