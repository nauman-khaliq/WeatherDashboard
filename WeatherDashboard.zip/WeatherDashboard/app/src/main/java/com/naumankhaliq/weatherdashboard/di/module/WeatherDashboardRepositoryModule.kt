/*
 * MIT License
 *
 * Copyright (c) 2024 Nauman Khaliq
 */

package com.naumankhaliq.weatherdashboard.di.module

import com.naumankhaliq.weatherdashboard.data.repository.WeatherDashboardRepositoryImp
import com.naumankhaliq.weatherdashboard.domain.WeatherDashboardRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityRetainedComponent
import dagger.hilt.android.scopes.ActivityRetainedScoped
import kotlinx.coroutines.ExperimentalCoroutinesApi

/**
 * Currently WeatherDashboardRepository is only used in ViewModels.
 * MainViewModel is not injected using @HiltViewModel so can't install in ViewModelComponent.
 */
@ExperimentalCoroutinesApi
@InstallIn(ActivityRetainedComponent::class)
@Module
abstract class WeatherDashboardRepositoryModule {

    /**
     * Binds DefaultIMoviesRepository returns [WeatherDashboardRepository] which is an interface and parent of [WeatherDashboardRepositoryImp]
     * @param repository of type [WeatherDashboardRepositoryImp]
     * @return WeatherDashboardRepository
     */
    @ActivityRetainedScoped
    @Binds
    abstract fun bindWeatherDashboardRepository(repository: WeatherDashboardRepositoryImp): WeatherDashboardRepository
}
