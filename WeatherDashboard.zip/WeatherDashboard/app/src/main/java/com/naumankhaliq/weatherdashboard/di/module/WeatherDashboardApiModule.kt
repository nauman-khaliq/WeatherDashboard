/*
 * MIT License
 *
 * Copyright (c) 2022 Nauman Khaliq
 *
 */

package com.naumankhaliq.weatherdashboard.di.module

import com.naumankhaliq.weatherdashboard.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import com.naumankhaliq.weatherdashboard.data.remote.api.WeatherDashboardService
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import javax.inject.Singleton

/**
 * [WeatherDashboardApiModule] that will handle api related dependencies.
 * [WeatherDashboardAppModule] is included in this module
 */
@InstallIn(SingletonComponent::class)
@Module(includes = [WeatherDashboardAppModule::class])
class WeatherDashboardApiModule {

    /**
     * Provides retrofit service with Moshi converter and okhttp client
     * @param okHttpClient of type [OkHttpClient]
     * @return [WeatherDashboardService]
     */
    @Singleton
    @Provides
    fun provideRetrofitService(okHttpClient: OkHttpClient): WeatherDashboardService = Retrofit.Builder()
        .addConverterFactory(
            MoshiConverterFactory.create(
                Moshi.Builder()
                    .addLast(KotlinJsonAdapterFactory())
                    .build()
            )
        )
        .baseUrl(BuildConfig.BASE_URL)
        .client(okHttpClient)
        .build()
        .create(WeatherDashboardService::class.java)
}
