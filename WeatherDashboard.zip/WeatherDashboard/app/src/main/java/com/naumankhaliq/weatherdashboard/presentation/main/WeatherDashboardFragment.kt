/*
 * MIT License
 *
 * Copyright (c) 2025 Nauman Khaliq
 *
 */
package com.naumankhaliq.weatherdashboard.presentation.main

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import coil.load
import com.naumankhaliq.weatherdashboard.R
import com.naumankhaliq.weatherdashboard.data.util.DataFrom
import com.naumankhaliq.weatherdashboard.databinding.FragmentWeatherDashboardBinding
import com.naumankhaliq.weatherdashboard.domain.WeatherData
import com.naumankhaliq.weatherdashboard.presentation.model.State
import com.naumankhaliq.weatherdashboard.presentation.base.BaseFragment
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import javax.inject.Inject

// Instances of this class are fragments representing a single
// object in our collection.

@ExperimentalCoroutinesApi
@AndroidEntryPoint
class WeatherDashboardFragment : BaseFragment<MainViewModel, FragmentWeatherDashboardBinding>() {
    override val mViewModel: MainViewModel by activityViewModels()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return mViewBinding.root
    }

    /**
     * Gets weather data through viewmodel from api
     */
    private fun getWeatherData(city: String) {
        mViewModel.getWeatherDataForCity(city)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        mViewModel.getLastSearchedCity().let {
            if (it.isNotEmpty()) {
                getWeatherData(it)
            }
        }
        initViews()
        observeWeatherData()
    }

    override fun getViewBinding(): FragmentWeatherDashboardBinding {
        return FragmentWeatherDashboardBinding.inflate(layoutInflater)
    }

    /**
     * Initializing views and register click listeners
     */
    private fun initViews() {
        mViewBinding.run {
            searchBtn.setOnClickListener {
                if (searchEditText.text.toString().trim().isNotEmpty())
                    getWeatherData(searchEditText.text.toString().trim())
            }

        }
    }


    /**
     * Observing users list State Flow data with states
     */
    @SuppressLint("NotifyDataSetChanged")
    private fun observeWeatherData() {
        lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                mViewModel.weatherData.collect {
                    when (it) {
                        is State.Loading -> {
                            Log.i("LoadingStateChecking", "Weather api Loading Called")
                            mViewBinding.searchBtn.isEnabled = false
                            mViewBinding.loader.visibility = View.VISIBLE
                        }

                        is State.Success -> {
                            Log.i("LoadingStateChecking", "Weather api Success Called")
                            it.data?.let { weatherData ->
                                populateWeatherData(weatherData)
                                mViewModel.saveLastSearchedCity(cityName = weatherData.cityName)
                            }
                            mViewBinding.loader.visibility = View.GONE
                            mViewBinding.searchBtn.isEnabled = true
                        }

                        is State.Error -> {
                            Log.i("LoadingStateChecking", "Weather api ERROR Called")
                            val obj = it.message
                            Toast.makeText(context, obj, Toast.LENGTH_SHORT).show()
                            mViewBinding.loader.visibility = View.GONE
                            mViewBinding.searchBtn.isEnabled = true
                        }

                        is State.Idle -> {}
                    }
                }
            }
        }
    }

    /**
     * Populates weather data to weather card
     */
    private fun populateWeatherData(weatherData: WeatherData) {
        mViewBinding.weatherCard.run {
            cityNameTV.text = weatherData.cityName
            weatherConditionTV.text = weatherData.condition
            temperatureTV.text = "${weatherData.temperature.toInt()}°C"

            val iconUrl = "https://openweathermap.org/img/wn/${weatherData.iconCode}@2x.png"
            weatherIcon.load(iconUrl) {
                error(R.drawable.ic_broken_image)
                crossfade(true)
            }
        }
    }
}