package com.naumankhaliq.weatherdashboard.di

import com.naumankhaliq.weatherdashboard.data.repository.FakeWeatherDashboardRepository
import com.naumankhaliq.weatherdashboard.di.module.WeatherDashboardRepositoryModule
import com.naumankhaliq.weatherdashboard.domain.WeatherDashboardRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.components.SingletonComponent
import dagger.hilt.testing.TestInstallIn
import kotlinx.coroutines.ExperimentalCoroutinesApi
import javax.inject.Singleton

/**
 * TasksRepository binding to use in tests.
 *
 * Hilt will inject a [FakeWeatherDashboardRepository] instead of a [DefaultIMovieRepository].
 */
@OptIn(ExperimentalCoroutinesApi::class)
@Module
@TestInstallIn(
    components = [SingletonComponent::class],
    replaces = [WeatherDashboardRepositoryModule::class]
)
abstract class TestTasksRepositoryModule {
    @Singleton
    @Binds
    abstract fun bindRepository(repo: FakeWeatherDashboardRepository): WeatherDashboardRepository
}
