/*
 * MIT License
 *
 * Copyright (c) 2024 Nauman Khaliq
 *
 */

package com.naumankhaliq.weatherdashboard.data.repository


import com.naumankhaliq.weatherdashboard.data.remote.api.WeatherDashboardService
import com.naumankhaliq.weatherdashboard.data.remote.model.BaseResponse
import com.naumankhaliq.weatherdashboard.data.remote.model.weather.WeatherResponse
import com.naumankhaliq.weatherdashboard.data.remote.model.weather.toDomain
import com.naumankhaliq.weatherdashboard.data.util.Resource
import com.naumankhaliq.weatherdashboard.domain.WeatherDashboardRepository
import com.naumankhaliq.weatherdashboard.domain.WeatherData
import com.naumankhaliq.weatherdashboard.utils.MockResponseFileReader
import com.naumankhaliq.weatherdashboard.utils.TestRetrofitHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import retrofit2.Response
import javax.inject.Inject

/**
 * Singleton repository for fetching data from remote and storing it in database
 * for offline capability. This is Single source of data.
 */
@ExperimentalCoroutinesApi
open class FakeWeatherDashboardRepository @Inject constructor(
) : WeatherDashboardRepository {

    var testApiService: WeatherDashboardService
    private var mockWebServer: MockWebServer = MockWebServer()

    init {
        runBlocking {
            withContext(Dispatchers.IO) {
                mockWebServer.start()
            }
        }
        testApiService = TestRetrofitHelper.getTestRetrofitServiceForMockServer<WeatherDashboardService>(mockWebServer)
    }

    override fun getWeatherData(cityName: String): Flow<Resource<WeatherData?>> {
        return object: NetworkBoundRepository<WeatherResponse, WeatherData?>() {
            override suspend fun fetchFromRemote(): Response<WeatherResponse> {
                return testApiService.getOpenMapWeatherDataForCity("London")
            }

            override fun processResponse(response: WeatherResponse): WeatherData? {
                return response.toDomain()
            }

        }.asFlow().onCompletion {
            mockWebServer.shutdown()
        }
    }

}
