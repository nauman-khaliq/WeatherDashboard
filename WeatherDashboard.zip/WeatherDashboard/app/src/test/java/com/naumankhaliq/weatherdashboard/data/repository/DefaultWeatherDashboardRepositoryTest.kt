package com.naumankhaliq.weatherdashboard.data.repository

import android.content.Context
import android.os.Build
import androidx.test.core.app.ApplicationProvider
import com.naumankhaliq.weatherdashboard.data.remote.api.WeatherDashboardService
import com.naumankhaliq.weatherdashboard.data.util.Resource
import com.naumankhaliq.weatherdashboard.utils.MockResponseFileReader
import com.naumankhaliq.weatherdashboard.utils.TestRetrofitHelper
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import dagger.hilt.android.testing.HiltTestApplication
import io.mockk.MockKAnnotations
import io.mockk.impl.annotations.MockK
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@HiltAndroidTest
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [Build.VERSION_CODES.LOLLIPOP], application = HiltTestApplication::class)
class DefaultWeatherDashboardRepositoryTest {

    @get:Rule
    var hiltRule = HiltAndroidRule(this)

    @OptIn(ExperimentalCoroutinesApi::class)
    private lateinit var repository: WeatherDashboardRepositoryImp

    @MockK
    lateinit var testApiService: WeatherDashboardService


    private lateinit var mockWebServer: MockWebServer

    @OptIn(ExperimentalCoroutinesApi::class)
    @Before
    fun setUp() {
        hiltRule.inject()
        MockKAnnotations.init()
        // get context -- since this is an instrumental test it requires
        // context from the running application
        val context = ApplicationProvider.getApplicationContext<Context>()
        // initialize the db and dao variable

        mockWebServer = MockWebServer()
        mockWebServer.start()
        testApiService =
            TestRetrofitHelper.getTestRetrofitServiceForMockServer<WeatherDashboardService>(
                mockWebServer
            )
        repository = WeatherDashboardRepositoryImp(testApiService)
    }

    @After
    fun tearDown() {
        mockWebServer.shutdown()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun tests_getWeatherData_is_getting_response_correctly_first_time() =
        runTest(UnconfinedTestDispatcher()) {
            val mockedResponse = MockResponseFileReader("weather_api_response.json").content
            mockWebServer.enqueue(
                MockResponse()
                    .setResponseCode(200)
                    .setBody(mockedResponse)
            )
            val res = repository.getWeatherData("London").toList()

            val firstEmission = res[0]

            when (firstEmission) {
                is Resource.Success -> {
                    assert(firstEmission.data != null)
                }

                is Resource.Failed -> {
                    assert(firstEmission.message.isNotEmpty())
                }
            }
        }

}