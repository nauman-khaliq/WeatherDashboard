package com.naumankhaliq.weatherdashboard.presentation.main

import android.os.Build
import com.naumankhaliq.weatherdashboard.data.remote.api.WeatherDashboardService
import com.naumankhaliq.weatherdashboard.data.repository.WeatherDashboardRepositoryImp
import com.naumankhaliq.weatherdashboard.data.util.DataFrom
import com.naumankhaliq.weatherdashboard.data.util.Resource
import com.naumankhaliq.weatherdashboard.domain.WeatherData
import com.naumankhaliq.weatherdashboard.presentation.model.State
import com.naumankhaliq.weatherdashboard.utils.PreferenceHelper
import com.naumankhaliq.weatherdashboard.utils.TestRetrofitHelper
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import dagger.hilt.android.testing.HiltTestApplication
import io.mockk.MockKAnnotations
import io.mockk.impl.annotations.MockK
import io.mockk.junit4.MockKRule
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltAndroidTest
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [Build.VERSION_CODES.LOLLIPOP], application = HiltTestApplication::class)
class MainViewModelTest {

    @get:Rule
    var hiltRule = HiltAndroidRule(this)

    @get:Rule
    val mockkRule = MockKRule(this)

    @MockK
    private lateinit var mainViewModelT: MainViewModel

    @MockK
    lateinit var testApiService: WeatherDashboardService

    @MockK
    lateinit var fakeRepository: FakeWeatherDashboardRepository

    @MockK
    @Inject
    lateinit var preferenceHelper: PreferenceHelper

    private lateinit var mockWebServer: MockWebServer


    @Before
    fun setUp() {
        hiltRule.inject()
        MockKAnnotations.init()
        mockWebServer = MockWebServer()
        mockWebServer.start()
        testApiService =
            TestRetrofitHelper.getTestRetrofitServiceForMockServer<WeatherDashboardService>(mockWebServer)
        fakeRepository = FakeWeatherDashboardRepository(testApiService)
        mainViewModelT = MainViewModel(fakeRepository, preferenceHelper)
    }

    @After
    fun tearDown() {
        mockWebServer.close()
    }

    @Test
    fun test_state_flows_are_in_idle_state() {
        assert(mainViewModelT.weatherData.value is State.Idle)
    }

    @Test
    fun test_movies_state_flow_is_behaving_correctly() = runTest(UnconfinedTestDispatcher()) {
        mainViewModelT.getWeatherDataForCity("London")
        mainViewModelT.weatherData.value.let { state ->
            when (state) {
                is State.Loading -> {
                    assert(state.isLoading() == true)
                }
                else -> {}
            }
        }
        fakeRepository.emitWeatherDataFlow(Resource.Success(WeatherData("London", 108.0, "Cloudy", ""), DataFrom.REMOTE))
        mainViewModelT.weatherData.value.let { state ->
            when (state) {
                is State.Success -> {
                    assert(state.data != null)
                }
                else -> {}
            }
        }
    }

    class FakeWeatherDashboardRepository(
        apiService: WeatherDashboardService
    ) : WeatherDashboardRepositoryImp(apiService) {
        private val weatherDataFlow = MutableSharedFlow<Resource<WeatherData?>>()
        suspend fun emitWeatherDataFlow(value: Resource<WeatherData?>) = weatherDataFlow.emit(value)

        override fun getWeatherData(cityName: String): Flow<Resource<WeatherData?>> {
            return weatherDataFlow
        }
    }

}